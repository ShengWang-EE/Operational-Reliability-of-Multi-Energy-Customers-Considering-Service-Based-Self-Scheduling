tic
clear
simulationTimes = 1;
[NM,NL,NK,uncertaintyLevel,originalServiceByEnergy,eta,CDF,consumptionOfTotal,costOfTotal,clCoefficiency,CDFm,clPortion,slPortion,lambda] = getParameters();
convergence.EENS = zeros(simulationTimes,1);percentageSTD.EENS = zeros(simulationTimes,1);
convergence.electricityEENS = zeros(simulationTimes,1);percentageSTD.electricityEENS = zeros(simulationTimes,1);
%%
%cost
sumf = zeros(1,NK); sumLLC=zeros(1,NK); sumLCC = zeros(1,NK); sumLSC = zeros(1,NK);
% reiability
sumLOLP.time = zeros(size(NL,NK)); sumLOLP.energy = zeros(size(1,NK)); sumLOLP.system = zeros(1,1); 
sumEENS.time = zeros(size(NL,NK)); sumEENS.energy = zeros(size(1,NK)); sumEENS.system = zeros(1,1); 
sumActualLOLP.time = zeros(size(NL,NK)); sumActualLOLP.energy = zeros(size(1,NK)); sumActualLOLP.system = zeros(1,1); 
sumActualEENS.time = zeros(size(NL,NK)); sumActualEENS.energy = zeros(size(1,NK)); sumActualEENS.system = zeros(1,1); 
% hist
hist.serviceShiftOut = zeros(NM,1);
hist.energyShiftIn = zeros(NL,1);
hist.periodShiftIn = zeros(NK,1);
%%
allCost = zeros(1,simulationTimes);
for i = 1:simulationTimes
    i % disply
    [f, x, LOLP, EENS, decoupledCost,operationalCost,newLoad, newActualLoad,actualLOLP,actualEENS] = f_selfScheduleUsingGA();
    convergence.EENS(i) = EENS.system;
    percentageSTD.EENS(i) = std(convergence.EENS(1:i),1,1) ./ mean(convergence.EENS(1:i),1);
    convergence.electricityEENS(i) = EENS.byEnergy(1);
    percentageSTD.electricityEENS(i) = std(convergence.electricityEENS(1:i),1,1) ./ mean(convergence.electricityEENS(1:i),1);
    allCost(i) = f;
    sumf = sumf + f; 
    sumLLC = sumLLC + operationalCost.LLC;
    sumLCC = sumLCC + operationalCost.LCC;
    sumLSC = sumLSC + operationalCost.LSC;

    sumLOLP.time = sumLOLP.time + LOLP.time;
    sumLOLP.energy = sumLOLP.energy + LOLP.energy;
    sumLOLP.system = sumLOLP.system + LOLP.system;
    sumEENS.time = sumEENS.time + EENS.time;
    sumEENS.energy = sumEENS.energy + EENS.energy;
    sumEENS.system = sumEENS.system + EENS.system;
    
    sumActualLOLP.time = sumActualLOLP.time + actualLOLP.time;
    sumActualLOLP.energy = sumActualLOLP.energy + actualLOLP.energy;
    sumActualLOLP.system = sumActualLOLP.system + actualLOLP.system;
    sumActualEENS.time = sumActualEENS.time + actualEENS.time;
    sumActualEENS.energy = sumActualEENS.energy + actualEENS.energy;
    sumActualEENS.system = sumActualEENS.system + actualEENS.system;
    %% decouple x
    cl = zeros(NM,NK); sl = zeros(NM,NK); newk = zeros(NM,NK);newl = zeros(NM,NK);
    clTemp = x(1:NK*NM);
    slTemp = x(NK*NM+1:2*NK*NM);
    newkTemp = x(2*NK*NM+1:3*NK*NM);
    newlTemp = x(3*NK*NM+1:4*NK*NM);
    for m = 1:NM
        cl(m,1:NK) = clTemp(((m-1)*NK+1):(m*NK));
        sl(m,1:NK) = slTemp(((m-1)*NK+1):(m*NK));
        newk(m,1:NK) = newkTemp(((m-1)*NK+1):(m*NK));
        newl(m,1:NK) = newlTemp(((m-1)*NK+1):(m*NK));
    end
    %% calculate histogram
    hist.serviceShiftOut = hist.serviceShiftOut + sum(cl,2) + sum(sl,2);
    hist.energyShiftIn = hist.energyShiftIn + [sum(sum(find(newl==1)));sum(sum(find(newl==2)));sum(sum(find(newl==3)))];
    for k = 1:NK
        hist.periodShiftIn(k) = hist.periodShiftIn(k) + sum(sum(find(newk==k)));
    end
end
%% reliability
averagef = sumf/simulationTimes; averageLLC = sumLLC/simulationTimes;
averageLCC = sumLCC/simulationTimes; averageLSC = sumLSC/simulationTimes;
averageLOLP.time = sumLOLP.time/simulationTimes;
averageLOLP.energy = sumLOLP.energy/simulationTimes;
averageLOLP.system = sumLOLP.system/simulationTimes;
averageLOLP.byEnergy = sum(averageLOLP.time)/24;
averageEENS.time = sumEENS.time/simulationTimes;
averageEENS.energy = sumEENS.energy/simulationTimes;
averageEENS.system = sumEENS.system/simulationTimes;
averageEENS.byEnergy = sum(averageEENS.time)/24;
averageActualLOLP.time = sumActualLOLP.time/simulationTimes;
averageActualLOLP.energy = sumActualLOLP.energy/simulationTimes;
averageActualLOLP.system = sumActualLOLP.system/simulationTimes;
averageActualLOLP.byEnergy = sum(averageActualLOLP.time)/24;
averageActualEENS.time = sumActualEENS.time/simulationTimes;
averageActualEENS.energy = sumActualEENS.energy/simulationTimes;
averageActualEENS.system = sumActualEENS.system/simulationTimes;
averageActualEENS.byEnergy = sum(averageActualEENS.time)/24;
%% hist
percentageHist.serviceShiftOut = hist.serviceShiftOut / sum(hist.serviceShiftOut);
percentageHist.energyShiftIn = hist.energyShiftIn / sum(hist.energyShiftIn);
percentageHist.periodShiftIn = hist.periodShiftIn / sum(hist.periodShiftIn);



%%

elapseTime = toc;
save('multiTimes.mat')
