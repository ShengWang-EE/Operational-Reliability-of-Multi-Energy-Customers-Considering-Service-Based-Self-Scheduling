function [Info_windunit] = MCS_loadLevel(mission_time)

%   Detailed explanation goes here
%input��unit_capacity_state,Lamda,unitstateno
unit_capacity_state  =  [0.58 0.87 1 0.87];%��λMW?

Lamda = [  0 1/4 0 0
           0 0 1/2 0
           0 0 0 1/12
           1/4 0 0 0];
unitstateno = 4; 
%�����дΪ?��unitstateno=size(unit_capacity_state,2)

for i =1:unitstateno
   Lamda(i,i)= -sum(Lamda(i,:));         
end     


% determine the inintial state

% p0 = linsolve([Lamda-eye(unitstateno);ones(1,unitstateno)],[zeros(4,1);1]);
% find(cumsum(p0)>rand(1))
Info_windunit(1,1)= 2;    %% State number
Info_windunit(1,2)= 0;    %% State start time
Info_windunit(1,3)= 0;    %% State end time, this value is unknown
Info_windunit(1,4)= unit_capacity_state(Info_windunit(1,1));    %% State capacity
Total_Dur = 0;
iter =1;

while Total_Dur < mission_time 
 %��β���   
    for i = 1:unitstateno 
       %�Խ������״̬��ģ��һ��
      a = log(rand(1));%log��ln
      state_no = Info_windunit(iter,1);
      b =  Lamda(state_no,i);  %% Transition rate Lamda�Ѿ��ǿ��Ƕ��ԭ���뿪ת���ɵ���ͣ�
      Dur(i) = - a /b;%P201��ʽ����״̬����һ��
       if Dur(i) <0   
           Dur(i) = 10^10; 
       end
    end
    %������һ����������״̬��
   [stateDur, Nextstate] = min(Dur);%   [Y,I] = MIN(X) returns the indices of the minimum values in vector I.
   Info_windunit(iter,3) = Info_windunit(iter,2) + stateDur;  
   Total_Dur = Info_windunit(iter,3);
   
   if Total_Dur < mission_time 
    iter = iter +1;
    Info_windunit(iter,1)= Nextstate;
    Info_windunit(iter,2)= Info_windunit((iter-1),3);    %% State start time
    Info_windunit(iter,3)= 0;    %% State end time
    Info_windunit(iter,4)= unit_capacity_state(Nextstate);    %% State capacity
   end
   
end
end








