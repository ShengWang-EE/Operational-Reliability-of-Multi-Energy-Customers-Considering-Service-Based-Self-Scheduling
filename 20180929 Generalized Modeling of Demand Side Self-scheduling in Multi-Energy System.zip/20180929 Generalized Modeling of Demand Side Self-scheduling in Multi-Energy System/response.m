clc
clear
load resultGA1.mat
%% given the sl, newk, newl, and calculate the deployed energy demand from each service
[deployedElectricityProportion, deployedGasProportion, deployedHeatProportion] = deal(zeros(7,24));
slElectricityService = [0	0	0	0	0
0	0	0	0	0
0	0	0	0	0
0	0	0	0	0
0	0	0	0	0
0	0	0	0	0
0	0	0	0	0
0.10758	1.16686	0.168	0	0.01691
0.22543	0.80375	0.26621	0	0.51769
0.30538	0.31202	0.13964	0	0.66104
0.3537	0.54951	0.51818	0	0.06394
0	0	0	0	0
0	0	0	0	0
0	0	0	0	0
0	0	0	0	0
0	0	0	0	0
0	0	0	0	0
0.47058	0.28842	0.03162	0.03331	0.1746
0.69472	0.58565	0.2383	0.24452	0.27667
0.76368	0.66813	0.30974	0.34235	0.03108
0.63511	0.69443	0.44558	0.60159	0.34298
0.03645	1.05712	0.34867	0.2528	0.08011
0.11384	0.17065	0.0222	0.39503	0.07206
0	0	0	0	0]';
slGasService = [0.09486
0.37473
0.04132
0.07708
0.20978
0.00852
0.08345
0.12689
0.02539
0.02256
0
0
0.42771
0.04631
0.02655
0.68586
0
0
0
0
0
0
0
0.21247]';
slHeatService = [0
0
0
0
0
0
0
0
1.22054
1.18486
0.11849
0.06274
1.25644
0.83588
0.24919
1.05197
0
0.45031
0.40826
1.5375
0.60277
1.12465
0
0]';
eta = [0.5 0.1 0.2 1 1 0.5 0.5;
       0.5 0.4 0.8 0 0 1   0.5;
       0.5 0.5 0   0 0 0.5 1  ;];% ��Ϊgas ��heat load�е�һ����Ҳ�ܱ�������Դ���
sl = [slElectricityService; slGasService; slHeatService];

deployedIn0 = [0	0.48905	0	0	0	0.46252	0	0	0.03616	0	0	0.61117	0.34355	0.0696	0.93047	0.01504	0	0	0	0	0	0	0.4954	0.12459
0.35963	0	0	0	0.04523	0	0	0.15546	0.20235	0	0	0	0	0	0	0	0	0.01046	0.16203	0.13547	0	0	0	0
0.3774	0	0.07174	0	0	0	0	0.91031	0	0	0	0.50489	0	0	0	0	0	0	0.84526	0	0	0.15119	0.61376	0];


for i = 1:7
    switch i
        case {1,2,3,4,5}
            oldEnergy = 1;
        case 6
            oldEnergy = 2;
        case 7
            oldEnergy = 3;
    end
    for k = 1:24
    switch newl(i,k)
        case 1 %electricity
            deployedElectricityProportion(i,newk(i,k)) = deployedElectricityProportion(i,newk(i,k)) + sl(i,k) * eta(oldEnergy,i) / eta(newl(i,k),i);
        case 2
            deployedGasProportion(i,newk(i,k)) = deployedGasProportion(i,newk(i,k)) + sl(i,k) * eta(oldEnergy,i) / eta(newl(i,k),i);
        case 3
            deployedHeatProportion(i,newk(i,k)) = deployedHeatProportion(i,newk(i,k)) + sl(i,k) * eta(oldEnergy,i) / eta(newl(i,k),i);
    end
    end
end
deployedElectricityProportion(deployedElectricityProportion==0)=0.0000000001;
deployedGasProportion(deployedGasProportion==0)=0.0000000001;
deployedHeatProportion(deployedHeatProportion==0)=0.0000000001;
for i = 1:5
    deployedElectricity(i,:) = deployedIn0(1,:) ./sum(deployedElectricityProportion(1:5,:)) .* deployedElectricityProportion(i,:);
    deployedGas(i,:) = deployedIn0(2,:) ./sum(deployedGasProportion(1:5,:)) .* deployedGasProportion(i,:);
    deployedHeat(i,:) = deployedIn0(3,:) ./sum(deployedHeatProportion(1:5,:)) .* deployedHeatProportion(i,:);
end





