clear
tic
[supply,load, service,windGeneration] = f_loadGenerating();
%% set the problem
[NM,NL,NK,uncertaintyLevel,originalServiceByEnergy,eta,CDF,consumptionOfTotal,costOfTotal,clCoefficiency,CDFm,clPortion,slPortion,lambda] = getParameters();




% constrains
% ����Ҫreshape��
clmin = zeros(NK*NM,1); slmin = zeros(NK*NM,1);
newkmin = ones(NK*NM,1); newkmax = NK * ones(NK*NM,1);
% ��Ҫreshape��
clmax = clPortion * service;
slmax = slPortion * service;
%find load<supply,those won't be curtailed or shifted
[iEnergy, iPeriod]  = find(supply > load);
for i = 1:size(iEnergy,1)
    iService = find(originalServiceByEnergy==iEnergy(i));
    for j = 1:size(iService,2)
        clmax(iService(j), iPeriod(i)) = 0;slmax(iService(j), iPeriod(i)) = 0;
    end    
end
% some services can not be shifted into some energies, renew boundaries
newlmin = ones(NM,NK); newlmax = NL*ones(NM,NK);
for m = 1:NM
    if m == 3
        newlmin(m,:) = 1; newlmax(m,:) = 2;
    end 
    if m == 4 || m == 5
        newlmin(m,:) = 1; newlmax(m,:) = 1;
    end 
end
clmax = reshape(clmax',[],1);slmax = reshape(slmax',[],1);
newlmin = reshape(newlmin',[],1);newlmax = reshape(newlmax',[],1);

LB = [clmin;slmin;newkmin;newlmin]; 
UB = [clmax;slmax;newkmax;newlmax];

% calculate the original cost
cl0 = zeros(NM*NK,1);sl0 = zeros(NM*NK,1);
newk0 = []; newl0 = []; newkTemp = [1:NK]'; newlTemp = ones(NK,1); 
for m=1:NM
    newk0 = [newk0;newkTemp];
    if m>=1 && m<=5
        newl0 = [newl0;newlTemp];
    else
        switch m
            case 6
                newl0 = [newl0;2*newlTemp];
            case 7
                newl0 = [newl0;3*newlTemp];
        end
    end
end
x0 = [cl0;sl0;newk0;newl0];

[originalCost,decoupled,newLoad,loadBeforeShiftIn,shiftInLoad,originalOperationalCost] = f_totalCost(x0,supply,load,newkmin,newkmax,newlmin,newlmax);
[originalLOLP,originalEENS,customerDamageCost] = f_reliabilityCalculation(load,supply);
%
objectiveFunction = @(x)f_totalCost(x,supply,load,newkmin,newkmax,newlmin,newlmax);
IntCon = (2*NM*NK+1):(4*NK*NM);
nvars = size(x0,1);
opts = optimoptions('ga','MaxStallGenerations',300,'FunctionTolerance',1e-10,...
    'MaxGenerations',3000,'PlotFcn',@gaplotbestfun,'PopulationSize',100);
%'UseParallel',1
[x,fval,exitflag,output,population,scores] = ga(objectiveFunction,nvars,[],[],[],[],LB,UB,[],IntCon,opts);
%% 
[f,decoupledCost,newLoad,loadBeforeShiftIn,shiftInLoad,operationalCost] = f_totalCost(x,supply,load,newkmin,newkmax,newlmin,newlmax);
% integrate the random failure of switches
newActualLoad = actualDeployLoadShifting(load,x,lambda);
% calculate the reliability performance
[LOLP,EENS,customerDamageCost] = f_reliabilityCalculation(newLoad,supply);
[actualLOLP,actualEENS,customerDamageCost] = f_reliabilityCalculation(newActualLoad,supply);

%% plot graph
% --- decouple x
cl = zeros(NM,NK); sl = zeros(NM,NK); newk = zeros(NM,NK);newl = zeros(NM,NK);
clTemp = x(1:NK*NM);
slTemp = x(NK*NM+1:2*NK*NM);
newkTemp = x(2*NK*NM+1:3*NK*NM);
newlTemp = x(3*NK*NM+1:4*NK*NM);
for m = 1:NM
    cl(m,1:NK) = clTemp(((m-1)*NK+1):(m*NK));
    sl(m,1:NK) = slTemp(((m-1)*NK+1):(m*NK));
    newk(m,1:NK) = newkTemp(((m-1)*NK+1):(m*NK));
    newl(m,1:NK) = newlTemp(((m-1)*NK+1):(m*NK));
end
% --- plot
% plot 11 is for outer loop
plot11.service = service;
plot11.serviceCurtailed = sum(cl,2);
plot11.serviceShited = sum(cl,2);

% plot 2 is for the inner loop of specific energy shift
for l = 1:NL
    plot2.EnergyShiftOut{l} = [loadBeforeShiftIn(l,:);sum(cl(find(originalServiceByEnergy==l),:),1);...
                                sum(sl(find(originalServiceByEnergy==l),:),1);]';
    plot3.energyShifitIn{l} = [loadBeforeShiftIn(l,:);shiftInLoad.fromElectricity(l,:);shiftInLoad.fromGas(l,:);shiftInLoad.fromHeat(l,:);]';

end
elapseTime = toc;
save('resultGA.mat')




