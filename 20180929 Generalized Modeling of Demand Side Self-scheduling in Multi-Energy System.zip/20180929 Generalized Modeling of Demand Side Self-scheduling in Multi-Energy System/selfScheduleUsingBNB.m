clear
tic
[supply,load, service] = f_loadGenerating();
%% set the problem
[NM,NL,NK,uncertaintyLevel,originalServiceByEnergy,eta,CDF,consumptionOfTotal,costOfTotal,clCoefficiency,CDFm,clPortion,slPortion,lambda] = getParameters();

% constrains
% ����Ҫreshape��
clmin = zeros(NK*NM,1); slmin = zeros(NK*NM,1);
newkmin = ones(NK*NM,1); newkmax = NK * ones(NK*NM,1);
% ��Ҫreshape��
clmax = clPortion * service;
slmax = slPortion * service;
%find load<supply,those won't be curtailed or shifted
[iService, iPeriod]  = find(supply > load);
clmax(iService, iPeriod) = 0;slmax(iService, iPeriod) = 0;
% some services can not be shifted into some energies, renew boundaries
newlmin = ones(NM,NK); newlmax = NL*ones(NM,NK);
for m = 1:NM
    if m == 3
        newlmin(m,:) = 1; newlmax(m,:) = 2;
    end 
    if m == 4 || m == 5
        newlmin(m,:) = 1; newlmax(m,:) = 1;
    end 
end
clmax = reshape(clmax',[],1);slmax = reshape(slmax',[],1);
newlmin = reshape(newlmin',[],1);newlmax = reshape(newlmax',[],1);

LB = [clmin;slmin;newkmin;newlmin]; 
UB = [clmax;slmax;newkmax;newlmax];

% calculate the original cost
cl0 = zeros(NM*NK,1);sl0 = zeros(NM*NK,1);
newk0 = []; newl0 = []; newkTemp = [1:NK]'; newlTemp = ones(NK,1); 
for m=1:NM
    newk0 = [newk0;newkTemp];
    if m>=1 && m<=5
        newl0 = [newl0;newlTemp];
    else
        switch m
            case 6
                newl0 = [newl0;2*newlTemp];
            case 7
                newl0 = [newl0;3*newlTemp];
        end
    end
end
x0 = [cl0;sl0;newk0;newl0];

[originalCost, originalDecoupledCost] = f_totalCost(x0,supply,load,newkmin,newkmax,newlmin,newlmax);

%
objectiveFunction = @(x)f_totalCost(x,supply,load,newkmin,newkmax,newlmin,newlmax);
IntCon = (2*NM*NK+1):(4*NK*NM);
nvars = size(x0,1);
xstat = zeros(nvars,1);xstat(IntCon) = 1;
BNBoptions = optimset('Tolx',1e-4,'MaxSQPIter',10000);
[errmsg,Z,X,t,c,fail] = BNB20Updated(objectiveFunction,x0,xstat,LB,UB,[],[],[],[],[],[],BNBoptions);
%% 
[f,decoupledCost,newLoad,shiftInLoad] = f_totalCost(x,supply,load);
% integrate the random failure of switches
newActualLoad = actualDeployLoadShifting(load,x,lambda);
% calculate the reliability performance
[LOLP,EENS,customerDamageCost] = f_reliabilityCalculation(newActualLoad,supply);

%% plot graph
% --- decouple x
cl = zeros(NM,NK); sl = zeros(NM,NK); newk = zeros(NM,NK);newl = zeros(NM,NK);
clTemp = x(1:NK*NM);
slTemp = x(NK*NM+1:2*NK*NM);
newkTemp = x(2*NK*NM+1:3*NK*NM);
newlTemp = x(3*NK*NM+1:4*NK*NM);
for m = 1:NM
    cl(m,1:NK) = clTemp(((m-1)*NK+1):(m*NK));
    sl(m,1:NK) = slTemp(((m-1)*NK+1):(m*NK));
    newk(m,1:NK) = newkTemp(((m-1)*NK+1):(m*NK));
    newl(m,1:NK) = newlTemp(((m-1)*NK+1):(m*NK));
end
% --- plot

for l = 1:NL
    figure
    resultToBePlotted{l} = [supply(l,:);load(l,:);newActualLoad(l,:);sum(cl(find(originalServiceByEnergy==l),:),1);...
        sum(sl(find(originalServiceByEnergy==l),:),1);shiftInLoad(l,:)]';
    plot(resultToBePlotted{l});
end

save('result.mat')
elapseTime = toc;



