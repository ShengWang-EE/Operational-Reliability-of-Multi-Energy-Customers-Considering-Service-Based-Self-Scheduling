function [newLoad] = loadMerging(load,Info)
NK = size(load,2); 
for k = 0:(NK-1)
    beginIndex = max(find(k >= Info(:,2)));
    endIndex = min(find((k+1) <= Info(:,3)));
    if beginIndex == endIndex
        load(k+1) = load(k+1) + Info(beginIndex,4);
    elseif beginIndex == endIndex - 1
        load(k+1) = load(k+1) + (Info(beginIndex,3) - k) * Info(beginIndex,4) + (k+1-Info(endIndex,2)) * Info(endIndex,4);
    else
        load(k+1) = load(k+1) + (Info(beginIndex,3) - k) * Info(beginIndex,4) + (k+1-Info(endIndex,2)) * Info(endIndex,4);
        for i = (beginIndex+1) : (endIndex-1)
        load(k+1) = load(k+1) + (Info(i,3)-Info(i,2)) * Info(i,4);
        end
    end
newLoad = load;
end