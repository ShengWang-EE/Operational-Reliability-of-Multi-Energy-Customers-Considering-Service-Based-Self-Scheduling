function [NM,NL,NK,uncertaintyLevel,originalServiceByEnergy,eta,CDF,consumptionOfTotal,costOfTotal,clCoefficiency,CDFm,clPortion,slPortion,lambda] = getParameters()
%% 
NM = 7;
NL = 3;
NK = 24;
%% MCS
uncertaintyLevel = 0.2;
%%
originalServiceByEnergy = [1 1 1 1 1 2 3]; %1=e,2=g,3=h
eta = [0.5 0.1 0.2 1 1 0.5 0.5;
       0.5 0.4 0.8 0 0 1   0.5;
       0.5 0.5 0   0 0 0.5 1  ;];% ��Ϊgas ��heat load�е�һ����Ҳ�ܱ�������Դ���
% calculate CDF $/kWh
CDFe = 22.6; CDFg = CDFe * mean(eta(2,:))/mean(eta(1,:)); CDFh = CDFe * mean(eta(3,:))/mean(eta(1,:));
CDF = [CDFe, CDFg, CDFh];
consumptionOfTotal = [8, 34, 9, 0.4*49, 0.6*49]/100;
costOfTotal = [3, 12, 2, 0.2*83, 0.8*83]/100;
clCoefficiency = 0.8; %������������Ӧ�ȱ���ʧ���ɳɱ�ҪС
CDFm =CDFe .* costOfTotal ./consumptionOfTotal * clCoefficiency; %decoupled cost by service, not by energy
CDFm = [CDFm, CDFg*clCoefficiency, CDFh*clCoefficiency];
%%

clPortion = 0.1; 
slPortion = 0.25;
% slPortion = 0;
%% 
lambda = 0.3;% /h
end