function [LOLP,EENS,customerDamageCost] = f_reliabilityCalculation(newActualLoad,supply)
[NM,NL,NK,uncertaintyLevel,originalServiceByEnergy,eta,CDF,consumptionOfTotal,costOfTotal,clCoefficiency,CDFm,clPortion,slPortion,lambda] = getParameters();
%% 
% LOLP.time = newActualLoad > supply;
% LOLP.time = LOLP.time';
% LOLP.energy = max(LOLP.time,[],2);
% LOLP.system = sum(LOLP.energy);
% LOLP.byEnergy = sum(LOLP.time) / 24;
% EENS.time = (newActualLoad - supply) .* (newActualLoad > supply);
% EENS.time = EENS.time';
% EENS.energy = sum(EENS.time,2);
% EENS.system = sum(EENS.energy);
% EENS.byEnergy = sum(EENS.time) / 24;
LOLP.time = newActualLoad > supply;
LOLP.time = LOLP.time';
LOLP.energy = max(LOLP.time,[],2);

LOLP.byEnergy = sum(LOLP.time) / 24;
LOLP.system = max(LOLP.byEnergy);
EENS.time = (newActualLoad - supply) .* (newActualLoad > supply);
EENS.time = EENS.time';
EENS.energy = sum(EENS.time,2);
EENS.system = sum(EENS.energy)/24;
EENS.byEnergy = sum(EENS.time) / 24;
customerDamageCost.time = zeros(NL,NK);
for l = 1:NL
    customerDamageCost.time(l,:) = (newActualLoad(l,:) - supply(l,:)) .* (newActualLoad(l,:) > supply(l,:)) * CDF(l);
end
customerDamageCost.energy = sum(customerDamageCost.time,2);
customerDamageCost.system = sum(customerDamageCost.energy);
end