function [Info_windsubsystem] = MCS_windfarm(mission_time)

%   Detailed explanation goes here
%input��unit_capacity_state,Lamda,unitstateno
unit_capacity_state  =  [0,0.5,1,1.5,2];%��λMW?

Lamda = [0,   0.039, 0.013, 0.008, 0.018;   %% Transition rate matrix 
         0.365, 0, 0.151, 0.045, 0.097;
         0.122, 0.220, 0, 0.192, 0.155;
         0.038, 0.093, 0.185, 0, 0.359;
         0.016, 0.012, 0.016, 0.067, 0; ];
unitstateno = 5; 
%�����дΪ?��unitstateno=size(unit_capacity_state,2)

for i =1:unitstateno
   Lamda(i,i)= -sum(Lamda(i,:));         
end     


%Suppose it starts from the best state: state 5, 
Info_windunit(1,1)= 5;    %% State number
Info_windunit(1,2)= 0;    %% State start time
Info_windunit(1,3)= 0;    %% State end time, this value is unknown
Info_windunit(1,4)= 2;    %% State capacity
Total_Dur = 0;
iter =1;

while Total_Dur < mission_time 
 %��β���   
    for i = 1:5 
       %�Խ������״̬��ģ��һ��
      a = log(rand(1));%log��ln
      state_no = Info_windunit(iter,1);
      b =  Lamda(state_no,i);  %% Transition rate Lamda�Ѿ��ǿ��Ƕ��ԭ���뿪ת���ɵ���ͣ�
      Dur(i) = - a /b;%P201��ʽ����״̬����һ��
       if Dur(i) <0   
           Dur(i) = 10^10; 
       end
    end
    %������һ����������״̬��
   [stateDur, Nextstate] = min(Dur);%   [Y,I] = MIN(X) returns the indices of the minimum values in vector I.
   Info_windunit(iter,3) = Info_windunit(iter,2) + stateDur;  
   Total_Dur = Info_windunit(iter,3);
   
   if Total_Dur < mission_time 
    iter = iter +1;
    Info_windunit(iter,1)= Nextstate;
    Info_windunit(iter,2)= Info_windunit((iter-1),3);    %% State start time
    Info_windunit(iter,3)= 0;    %% State end time
    Info_windunit(iter,4)= unit_capacity_state(Nextstate);    %% State capacity
   end
   
end

a =1;

% From here we consider the failures of wind farms 

wfarm_number_state  =  [250,249,248,247,246];    %% Represent how many units are available for each state 

%Suppose it starts from the best state: state 1, 
ReliabilityInfo_wfarm(1,1)= 1;    %% State number
ReliabilityInfo_wfarm(1,2)= 0;    %% State start time
ReliabilityInfo_wfarm(1,3)= 0;    %% State end time, this value is unknown
ReliabilityInfo_wfarm(1,4)= 250;    %% number of available untis in this state 
Total_Dur = 0;
iter =1;


lamda_unit = 1/3650; %����
Mu_unit =    1/50;%�޸���

 wfarm_rates = [250*lamda_unit, 0;
                249*lamda_unit, Mu_unit;
                248*lamda_unit, 2*Mu_unit;
                247*lamda_unit, 3*Mu_unit;
                             0, 4*Mu_unit;]; 


while Total_Dur < mission_time 
  
  state_no = ReliabilityInfo_wfarm(iter,1);  
  
  if  wfarm_rates(state_no,1) >0 
    a1 = log(rand(1));
    b1 =  wfarm_rates(state_no,1);  %% Transition rate 
    Dur1 = - a1 /b1;
  else    
    Dur1 = 10^10;      
  end    
    
  if  wfarm_rates(state_no,2) >0 
    a2 = log(rand(1));
    b2 =  wfarm_rates(state_no,2);  %% Transition rate 
    Dur2 = - a2 /b2;
  else    
    Dur2 = 10^10;      
  end 
  
  if Dur1 < Dur2  %% It will go to the next state  
    %dur1�����𻵣�dur2�����޸��������𻵣�
    ReliabilityInfo_wfarm(iter,3) = ReliabilityInfo_wfarm(iter,2) + Dur1;  
    Total_Dur = ReliabilityInfo_wfarm(iter,3);   
   
    if Total_Dur < mission_time   
      iter = iter +1;
      ReliabilityInfo_wfarm(iter,1)=  ReliabilityInfo_wfarm((iter-1),1)+1;    %% State number, go to next state����һ������ų�����Χ��ô�죿
      ReliabilityInfo_wfarm(iter,2)= ReliabilityInfo_wfarm((iter-1),3);    %% State start time
      ReliabilityInfo_wfarm(iter,3)= 0;    %% State end time, this value is unknown
      ReliabilityInfo_wfarm(iter,4)= wfarm_number_state(ReliabilityInfo_wfarm(iter,1));    %% available units  
    end
   
   
  else            %% It will go to the previous state��dur1>dur2���޸�һ��
    
    ReliabilityInfo_wfarm(iter,3) = ReliabilityInfo_wfarm(iter,2) + Dur2;  
    Total_Dur = ReliabilityInfo_wfarm(iter,3);   
   
    if Total_Dur < mission_time   
      iter = iter +1;
      ReliabilityInfo_wfarm(iter,1)= ReliabilityInfo_wfarm((iter-1),1)-1;    %% State number, go to previous state
      ReliabilityInfo_wfarm(iter,2)= ReliabilityInfo_wfarm((iter-1),3);    %% State start time
      ReliabilityInfo_wfarm(iter,3)= 0;    %% State end time, this value is unknown
      ReliabilityInfo_wfarm(iter,4)= wfarm_number_state(ReliabilityInfo_wfarm(iter,1));    %% available units  
    end  
             
  end


end 

% Combine wind unit model with the wind farm reliability model
% �ϲ�����subsystem����

[Info_windsubsystem] = MCS_windreliability(Info_windunit,ReliabilityInfo_wfarm, mission_time); 
%200��ĺ�1.5���ҵĺϲ���
%Info_windunit����ÿ������ĳ�������ReliabilityInfo_wfarm�Ļ��������ǳ˷���ϵ
%MCS_windreliability��MCS_gensubsystem��ͬ��
%������Ĳ�һ��= =һ���Ǽ�һ���ǳ�







