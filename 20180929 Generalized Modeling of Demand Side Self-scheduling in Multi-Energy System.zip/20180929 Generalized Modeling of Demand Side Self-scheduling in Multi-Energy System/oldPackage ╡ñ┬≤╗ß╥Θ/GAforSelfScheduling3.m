clear
tic
%% parameters
NK = 24; NL = 3; NM=50;
eta = [0.1 0.65 0.25];% from ref <<adequacy...
% eta = [1 1 1];% from ref <<adequacy..
%[cl,sl,newk,newl]
nvars = NK*NL + 3 * NK * NL * NM;
% x=ones(nvars,1);
penaltyMuptiplier = 100000;
%load curve
waterHeating = [0.5	0.25	0.15	0.25	0.25	1.5	3.5	4	3.75	3.5	3	1	2	1.75	2	2.25	3	3.5	3.25	3	2.5	2	1.25	1];
ambientHeating	= [3	2.5	2.5	2.5	2.5	3	3.5	4	3.75	2.5	2	2	1.75	2	2	2	2.5	2.5	2.5	2.5	3.25	3	3	3.25];
cooking = [0.2	0.2	0	0.2	0.2	0.2	0.2	0.65	1.3	1.3	2.1	1.7	1.5	0.8	0.4	0.2	0.4	0.85	1.05	1.25	1.75	1.5	0.8	0.4];
lightning = [1	0.5	0.3	0	0	0.5	0	0	0	0	0	0	0	0	0	0	0	0.25	1	2	2.5	2.5	2.5	1.5];
others = [1.5	0.75	0.75	0.35	0.35	1.15	1.5	2.25	3.75	5.25	4.5	4	3.5	4.25	3.5	2.8	3.25	4	6	6.75	6	4.85	3	2.25];
sumOfLoadCurve = waterHeating + ambientHeating + cooking + lightning + others;
electricityLoad = sumOfLoadCurve;
gasLoad = [4097.82	4098.87	4050.09	4022.87	4020.42	3983.7	3990.4	3873.55	3816.57	3822.01	3648.24	3467.36	3876.26	3948.27	3917.98	3877.56	3529.43	3343.65	3318.86	3274.55	3406.27	3695.28	3707.56 3940.55];
gasLoad = gasLoad / mean(gasLoad) * mean(sumOfLoadCurve) * 0.3; %normalize 
heatingLoad = [35.5	22.9	15.9	15.9	25.5	63.7	57.3	25.5	79.6	101.9	108.3	76.4	89.2	89.2	106.4	75.2	67.1	77.4	91.4	126.3	119.2	91.2	56.1	35.1];
heatingLoad = heatingLoad / mean(heatingLoad) * mean(sumOfLoadCurve) * 0.5; %normalize as half electricity load
load0 = [electricityLoad;gasLoad;heatingLoad];
%supply curve
electricitySupply = mean(sumOfLoadCurve) * ones(1,24);
gasSupply = mean(gasLoad) * ones(1,24);
heatSupply = mean(heatingLoad) * ones(1,24)+0.5;%in case fixed load exceed supply
supply = [electricitySupply;gasSupply;heatSupply];
% parameters
FLXe = lightning + others;
FLXepctg = (lightning + others)./sumOfLoadCurve;

%% boundaries
newkmin = ones(NK*NL*NM,1); newkmax = 24 * ones(NK*NL*NM,1);
newlmin = ones(NK*NL*NM,1); newlmax = 3 * ones(NK*NL*NM,1);
clmin = zeros(NK*NL,1); 
clemax = ambientHeating';
clgmax = (ambientHeating ./ sumOfLoadCurve .* gasLoad)';
clhmax = (ambientHeating ./ sumOfLoadCurve .* heatingLoad)';
slmin = zeros(NK*NL*NM,1);
slemax0 = (waterHeating + cooking)';
slgmax0 = ((waterHeating + cooking) ./ sumOfLoadCurve .* gasLoad)';
slhmax0 = ((waterHeating + cooking) ./ sumOfLoadCurve .* heatingLoad)';
    slemax = kron([(waterHeating + cooking)'/NM],ones(NM,1));
    slgmax = kron([((waterHeating + cooking) ./ sumOfLoadCurve .* gasLoad)'/NM],ones(NM,1));
    slhmax = kron([((waterHeating + cooking) ./ sumOfLoadCurve .* heatingLoad)'/NM],ones(NM,1));
LB = [clmin;slmin;newkmin;newlmin]; 
UB = [clemax;clgmax;clhmax;slemax;slgmax;slhmax;newkmax;newlmax];
IntCon = (NK*NL+NL*NK*NM+1):(nvars);
%% ga
fitnessfcn = @(x)CCandSC3(x,NK,NL,NM,load0, supply,eta);
nonLinearConstrain = @(x)LOPconstrain2(x,load0,supply,NK,NL,NM,eta);
opts = optimoptions('ga','MaxStallGenerations',100,'FunctionTolerance',1e-10,...
    'MaxGenerations',1000, 'PopulationSize',100,'UseParallel',1,'PlotFcn',{@gaplotbestfun,@gaplotscorediversity});
% 'PopulationSize',200,'CrossoverFraction',0.5,
[x,fval,exitflag,output,population,scores] = ga(fitnessfcn,nvars,[],[],[],[],LB,UB,nonLinearConstrain,IntCon,opts);


%% result presenting
% decouple x
cl = x(1:NK*NL);
cle = cl(1:NK);clg = cl(NK+1:2*NK);clh = cl(2*NK+1:3*NK);
sl = x(NK*NL+1:NK*NL+NK*NL*NM);
sle = sl(1:NK*NM);slg = sl(NK*NM+1:2*NK*NM);slh = sl(2*NK*NM+1:3*NK*NM);
newk = x(NK*NL+NK*NL*NM+1:NK*NL+2*NK*NL*NM);
newke = newk(1:NK*NM);newkg = newk(NK*NM+1:2*NK*NM);newkh = newk(2*NK*NM+1:3*NK*NM);
newl = x(NK*NL+2*NK*NL*NM+1:NK*NL+3*NK*NL*NM);
newle = newl(1:NK*NM);newlg = newl(NK*NM+1:2*NK*NM);newlh = newl(2*NK*NM+1:3*NK*NM);
% curtail and shift out
for k=1:NK
    newLoad(1,k) = load0(1,k) - cle(k) - sum(sle((k-1)*NM+1:k*NM));
    newLoad(2,k) = load0(2,k) - clg(k) - sum(slg((k-1)*NM+1:k*NM));
    newLoad(3,k) = load0(3,k) - clh(k) - sum(slh((k-1)*NM+1:k*NM));
end
% shift in 
for l=1:NL
    for k=1:NK
        for m=1:NM
        kindex = (l-1)*NK + k; % 
        mindex = (l-1)*(k-1)*NM + m;
        newLoad(newl(mindex),newk(mindex)) = newLoad(newl(mindex),newk(mindex)) + sl(mindex) * eta(l) / eta(newl(mindex));
    
        end
    end
end
deltaLoadSupply = newLoad-supply;
deltaLoadSupply(find(deltaLoadSupply<0))=0;
% LOP = sum(sum((deltaLoadSupply),2) .* [CDFe1;CDFg1;CDFh1]);
% add up
% f0 = CC + SC;
% 
fixedLoad = [FLXe;gasLoad-clgmax'-slgmax0';heatingLoad-clhmax'-slhmax0'];
deltaFixedLoadSupply = fixedLoad-supply;
deltaFixedLoadSupply(find(deltaFixedLoadSupply<0))=0;
% LOPFixedLoad = sum(sum((deltaFixedLoadSupply),2) .* [CDFe1;CDFg1;CDFh1]);
%
electricityResults = [supply(1,:);load0(1,:);newLoad(1,:);fixedLoad(1,:)]';
gasResults = [supply(2,:);load0(2,:);newLoad(2,:);fixedLoad(2,:)]';
heatResults = [supply(3,:);load0(3,:);newLoad(3,:);fixedLoad(3,:)]';

toc