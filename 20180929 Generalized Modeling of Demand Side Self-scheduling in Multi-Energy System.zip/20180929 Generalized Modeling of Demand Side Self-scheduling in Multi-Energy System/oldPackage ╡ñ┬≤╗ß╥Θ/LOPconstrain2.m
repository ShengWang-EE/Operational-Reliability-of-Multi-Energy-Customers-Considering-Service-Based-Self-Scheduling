function [c,ceq] = LOPconstrain2(x,load0,supply,NK,NL,NM,eta)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
% load outage penalty LOP
% decouple x
cl = x(1:NK*NL);
cle = cl(1:NK);clg = cl(NK+1:2*NK);clh = cl(2*NK+1:3*NK);
sl = x(NK*NL+1:NK*NL+NK*NL*NM);
sle = sl(1:NK*NM);slg = sl(NK*NM+1:2*NK*NM);slh = sl(2*NK*NM+1:3*NK*NM);
newk = x(NK*NL+NK*NL*NM+1:NK*NL+2*NK*NL*NM);
newke = newk(1:NK*NM);newkg = newk(NK*NM+1:2*NK*NM);newkh = newk(2*NK*NM+1:3*NK*NM);
newl = x(NK*NL+2*NK*NL*NM+1:NK*NL+3*NK*NL*NM);
newle = newl(1:NK*NM);newlg = newl(NK*NM+1:2*NK*NM);newlh = newl(2*NK*NM+1:3*NK*NM);
% curtail and shift out
for k=1:NK
    newLoad(1,k) = load0(1,k) - cle(k) - sum(sle((k-1)*NM+1:k*NM));
    newLoad(2,k) = load0(2,k) - clg(k) - sum(slg((k-1)*NM+1:k*NM));
    newLoad(3,k) = load0(3,k) - clh(k) - sum(slh((k-1)*NM+1:k*NM));
end
% shift in 
for l=1:NL
    for k=1:NK
        for m=1:NM
        kindex = (l-1)*NK + k; % 
        mindex = (l-1)*(k-1)*NM + m;
        newLoad(newl(mindex),newk(mindex)) = newLoad(newl(mindex),newk(mindex)) + sl(mindex) * eta(l) / eta(newl(mindex));
    
        end
    end
end
deltaLoadSupply = newLoad-supply;

ceq = [];
c = deltaLoadSupply;
end

