function [c,ceq] = LOPconstrain(x,load0,supply,NK,NL,eta)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
% load outage penalty LOP
% decouple x
cl = x(1:NK*NL);
cle = cl(1:NK);clg = cl(NK+1:2*NK);clh = cl(2*NK+1:3*NK);
sl = x(NK*NL+1:2*NK*NL);
sle = sl(1:NK);slg = sl(NK+1:2*NK);slh = sl(2*NK+1:3*NK);
newk = x(2*NK*NL+1:3*NK*NL);
newke = newk(1:NK);newkg = newk(NK+1:2*NK);newkh = newk(2*NK+1:3*NK);
newl = x(3*NK*NL+1:4*NK*NL);
newle = newl(1:NK);newlg = newl(NK+1:2*NK);newlh = newl(2*NK+1:3*NK);
% curtail and shift out

newLoad(1,:) = load0(1,:) - cle - sle;
newLoad(2,:) = load0(2,:) - clg - slg;
newLoad(3,:) = load0(3,:) - clh - slh;
% shift in 
for l=1:NL
    for k=1:NK
        index = (l-1)*NK + k; % index in sle,newk,newl,...
        newLoad(newl(index),newk(index)) = newLoad(newl(index),newk(index)) + sl(index) * eta(l) / eta(newl(index));
    end
end
deltaLoadSupply = newLoad-supply;

ceq = [];
c = deltaLoadSupply;
end

