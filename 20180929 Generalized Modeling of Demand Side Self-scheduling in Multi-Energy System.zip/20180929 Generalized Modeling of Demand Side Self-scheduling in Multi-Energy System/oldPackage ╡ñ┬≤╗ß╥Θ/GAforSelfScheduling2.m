clear
tic
%% parameters
NK = 24; NL = 3; NM=5;
eta = [0.1 0.65 0.25];% from ref <<adequacy...
% eta = [1 1 1];% from ref <<adequacy..
%[cl,sl,newk,newl]
nvars = NK*NL + 3 * NK * NL * NM;
% x=ones(4 * NK * NL,1);
penaltyMuptiplier = 100000;
%load curve
waterHeating = [0.5	0.25	0.15	0.25	0.25	1.5	3.5	4	3.75	3.5	3	1	2	1.75	2	2.25	3	3.5	3.25	3	2.5	2	1.25	1];
ambientHeating	= [3	2.5	2.5	2.5	2.5	3	3.5	4	3.75	2.5	2	2	1.75	2	2	2	2.5	2.5	2.5	2.5	3.25	3	3	3.25];
cooking = [0.2	0.2	0	0.2	0.2	0.2	0.2	0.65	1.3	1.3	2.1	1.7	1.5	0.8	0.4	0.2	0.4	0.85	1.05	1.25	1.75	1.5	0.8	0.4];
lightning = [1	0.5	0.3	0	0	0.5	0	0	0	0	0	0	0	0	0	0	0	0.25	1	2	2.5	2.5	2.5	1.5];
others = [1.5	0.75	0.75	0.35	0.35	1.15	1.5	2.25	3.75	5.25	4.5	4	3.5	4.25	3.5	2.8	3.25	4	6	6.75	6	4.85	3	2.25];
sumOfLoadCurve = waterHeating + ambientHeating + cooking + lightning + others;
electricityLoad = sumOfLoadCurve;
gasLoad = [4097.82	4098.87	4050.09	4022.87	4020.42	3983.7	3990.4	3873.55	3816.57	3822.01	3648.24	3467.36	3876.26	3948.27	3917.98	3877.56	3529.43	3343.65	3318.86	3274.55	3406.27	3695.28	3707.56 3940.55];
gasLoad = gasLoad / mean(gasLoad) * mean(sumOfLoadCurve) * 0.3; %normalize 
heatingLoad = [35.5	22.9	15.9	15.9	25.5	63.7	57.3	25.5	79.6	101.9	108.3	76.4	89.2	89.2	106.4	75.2	67.1	77.4	91.4	126.3	119.2	91.2	56.1	35.1];
heatingLoad = heatingLoad / mean(heatingLoad) * mean(sumOfLoadCurve) * 0.5; %normalize as half electricity load
load0 = [electricityLoad;gasLoad;heatingLoad];
%supply curve
electricitySupply = mean(sumOfLoadCurve) * ones(1,24);
gasSupply = mean(gasLoad) * ones(1,24);
heatSupply = mean(heatingLoad) * ones(1,24)+0.5;%in case fixed load exceed supply
supply = [electricitySupply;gasSupply;heatSupply];
% parameters
FLXe = lightning + others;
FLXepctg = (lightning + others)./sumOfLoadCurve;

%% boundaries
newkmin = ones(NK*NL*NM,1); newkmax = 24 * ones(NK*NL*NM,1);
newlmin = ones(NK*NL*NM,1); newlmax = 3 * ones(NK*NL*NM,1);
clmin = zeros(NK*NL,1); 
clemax = ambientHeating';
clgmax = (ambientHeating ./ sumOfLoadCurve .* gasLoad)';
clhmax = (ambientHeating ./ sumOfLoadCurve .* heatingLoad)';
slmin = zeros(NK*NL*NM,1);

slemax = (waterHeating + cooking)'/NM;
slgmax = ((waterHeating + cooking) ./ sumOfLoadCurve .* gasLoad)'/NM;
slhmax = ((waterHeating + cooking) ./ sumOfLoadCurve .* heatingLoad)'/NM;
LB = [clmin;slmin;newkmin;newlmin]; 
UB = [clemax;clgmax;clhmax;slemax;slgmax;slhmax;newkmax;newlmax];
IntCon = (2*NL*NK+1):(4*NK*NL);
%% ga
fitnessfcn = @(x)CCandSC2(x,NK,NL,load0, supply,eta);
nonLinearConstrain = @(x)LOPconstrain(x,load0,supply,NK,NL,eta);
opts = optimoptions('ga','MaxStallGenerations',100,'FunctionTolerance',1e-10,...
    'MaxGenerations',1000, 'PopulationSize',100,'UseParallel',1,'PlotFcn',{@gaplotbestfun,@gaplotscorediversity});
% 'PopulationSize',200,'CrossoverFraction',0.5,
[x,fval,exitflag,output,population,scores] = ga(fitnessfcn,nvars,[],[],[],[],LB,UB,nonLinearConstrain,IntCon,opts);


%% result presenting
% decouple x
cl = x(1:NK*NL);
cle = cl(1:NK);clg = cl(NK+1:2*NK);clh = cl(2*NK+1:3*NK);
sl = x(NK*NL+1:2*NK*NL);
sle = sl(1:NK);slg = sl(NK+1:2*NK);slh = sl(2*NK+1:3*NK);
newk = x(2*NK*NL+1:3*NK*NL);
newke = newk(1:NK);newkg = newk(NK+1:2*NK);newkh = newk(2*NK+1:3*NK);
newl = x(3*NK*NL+1:4*NK*NL);
newle = newl(1:NK);newlg = newl(NK+1:2*NK);newlh = newl(2*NK+1:3*NK);
% CC
CDFe1 = 22.6; CDFg1 = CDFe1 * eta(2)/eta(1); CDFh1 = CDFe1 * eta(3)/eta(1);
CC = sum(cle) * CDFe1 + sum(clg) * CDFg1 + sum(clh) * CDFh1;
% SC
sum_sle = 0;sum_slg = 0;sum_slh = 0;
for k=1:NK
    sum_sle = sum_sle + sle(k) * CDFe1 /24 * abs((newke(k)-k));
    sum_slg = sum_slg + slg(k) * CDFg1 /24 * abs((newkg(k)-k));
    sum_slh = sum_slh + slh(k) * CDFh1 /24 * abs((newkh(k)-k));
end
SC = sum_sle + sum_slg + sum_slh;
% load outage penalty LOP
% curtail and shift out
newLoad(1,:) = load0(1,:) - cle - sle;
newLoad(2,:) = load0(2,:) - clg - slg;
newLoad(3,:) = load0(3,:) - clh - slh;
% shift in 
for l=1:NL
    for k=1:NK
        index = (l-1)*NK + k; % index in sle,newk,newl,...
        newLoad(newl(index),newk(index)) = newLoad(newl(index),newk(index)) + sl(index) * eta(l) / eta(newl(index));
    end
end
deltaLoadSupply = newLoad-supply;
deltaLoadSupply(find(deltaLoadSupply<0))=0;
LOP = sum(sum((deltaLoadSupply),2) .* [CDFe1;CDFg1;CDFh1]);
% add up
% f0 = CC + SC;
% 
fixedLoad = [FLXe;gasLoad-clgmax'-slgmax';heatingLoad-clhmax'-slhmax'];
deltaFixedLoadSupply = fixedLoad-supply;
deltaFixedLoadSupply(find(deltaFixedLoadSupply<0))=0;
LOPFixedLoad = sum(sum((deltaFixedLoadSupply),2) .* [CDFe1;CDFg1;CDFh1]);
%
electricityResults = [supply(1,:);load0(1,:);newLoad(1,:);fixedLoad(1,:)]';
gasResults = [supply(2,:);load0(2,:);newLoad(2,:);fixedLoad(2,:)]';
heatResults = [supply(3,:);load0(3,:);newLoad(3,:);fixedLoad(3,:)]';

toc