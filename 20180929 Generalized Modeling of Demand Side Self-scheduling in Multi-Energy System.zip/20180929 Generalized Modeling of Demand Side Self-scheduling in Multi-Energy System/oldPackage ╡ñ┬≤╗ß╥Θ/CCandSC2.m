function [f] = CCandSC2(x,NK,NL,load0, supply,eta)
% decouple x
cl = x(1:NK*NL);
cle = cl(1:NK);clg = cl(NK+1:2*NK);clh = cl(2*NK+1:3*NK);
sl = x(NK*NL+1:2*NK*NL);
sle = sl(1:NK);slg = sl(NK+1:2*NK);slh = sl(2*NK+1:3*NK);
newk = x(2*NK*NL+1:3*NK*NL);
newke = newk(1:NK);newkg = newk(NK+1:2*NK);newkh = newk(2*NK+1:3*NK);
newl = x(3*NK*NL+1:4*NK*NL);
newle = newl(1:NK);newlg = newl(NK+1:2*NK);newlh = newl(2*NK+1:3*NK);
% CC
CDFe1 = 22.6; CDFg1 = CDFe1 * eta(2)/eta(1); CDFh1 = CDFe1 * eta(3)/eta(1);
CC = sum(cle) * CDFe1 + sum(clg) * CDFg1 + sum(clh) * CDFh1;
% SC
sum_sle = 0;sum_slg = 0;sum_slh = 0;
for k=1:NK
    sum_sle = sum_sle + sle(k) * CDFe1 /24 * abs((newke(k)-k));
    sum_slg = sum_slg + slg(k) * CDFg1 /24 * abs((newkg(k)-k));
    sum_slh = sum_slh + slh(k) * CDFh1 /24 * abs((newkh(k)-k));
end
SC = sum_sle + sum_slg + sum_slh;
% % load outage penalty LOP
% % curtail and shift out
% newLoad(1,:) = load0(1,:) - cle-sle;
% newLoad(2,:) = load0(2,:) - clg - slg;
% newLoad(3,:) = load0(3,:) - clh - slh;
% % shift in 
% for l=1:NL
%     for k=1:NK
%         index = (l-1)*NK + k; % index in sle,newk,newl,...
%         newLoad(newl(index),newk(index)) = newLoad(newl(index),newk(index)) + sl(index) * eta(l) / eta(newl(index));
%     end
% end
% deltaLoadSupply = newLoad-supply;
% deltaLoadSupply(find(deltaLoadSupply<0))=0;
% LOP = sum(sum((deltaLoadSupply),2) .* [CDFe1;CDFg1;CDFh1]);
% add up
f = CC + SC;
end
