clear
load delta20
% fig1
Eresult1 = [load0(1,:)-sle-cle;cle;sle;];
Gresult1 = [load0(2,:)-slg-clg;clg;slg;];
Hresult1 = [load0(3,:)-slh-clh;clh;slh;];
%fig2
EshiftFrom = zeros(3,NK);GshiftFrom = zeros(3,NK);HshiftFrom = zeros(3,NK);
for l = 1:NL
    for k = 1:NK
        i = (l-1)*NK+k;
        switch newl(i)
            case 1
                EshiftFrom(l,newk(i)) = EshiftFrom(l,newk(i)) + sl(i) * eta(l) / eta(newl(i));
            case 2
                GshiftFrom(l,newk(i)) = GshiftFrom(l,newk(i)) + sl(i) * eta(l) / eta(newl(i));
            case 3
                HshiftFrom(l,newk(i)) = HshiftFrom(l,newk(i)) + sl(i) * eta(l) / eta(newl(i));
        end
    end
end

Eresult2 = [load0(1,:)-sle-cle;
    EshiftFrom(1,:);
    EshiftFrom(2,:);
    EshiftFrom(3,:);
    electricitySupply];
Gresult2 = [load0(2,:)-slg-clg;
    GshiftFrom(1,:);
    GshiftFrom(2,:);
    GshiftFrom(3,:);
    gasSupply];
Hresult2 = [load0(3,:)-slh-clh;
    HshiftFrom(1,:);
    HshiftFrom(2,:);
    HshiftFrom(3,:);
    heatSupply];

%% transpose
Eresult1 = Eresult1';Gresult1 = Gresult1';Hresult1 = Hresult1';
Eresult2 = Eresult2';Gresult2 = Gresult2';Hresult2 = Hresult2';
setk = 1:24;
newke(ie)=[];newkg(ig)=[];newkh(ih)=[];
newle(ie)=[];newlg(ig)=[];newlh(ih)=[];
newkResult = [newke newkg newkh];
newlResult = [newle newlg newlh];