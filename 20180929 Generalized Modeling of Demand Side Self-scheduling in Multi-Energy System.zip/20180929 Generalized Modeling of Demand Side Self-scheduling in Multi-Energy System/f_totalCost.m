function [f,decoupled,newLoad,loadBeforeShiftIn,shiftInLoad,operationalCost] = f_totalCost(x,supply,load,newkmin,newkmax,newlmin,newlmax)
%F_OBJECTIVEFUNCTION Summary of this function goes here
%   Detailed explanation goes here
[NM,NL,NK,uncertaintyLevel,originalServiceByEnergy,eta,CDF,consumptionOfTotal,costOfTotal,clCoefficiency,CDFm] = getParameters();

%% decouple x
cl = zeros(NM,NK); sl = zeros(NM,NK); newk = zeros(NM,NK);newl = zeros(NM,NK);
clTemp = x(1:NK*NM);
slTemp = x(NK*NM+1:2*NK*NM);
newkTemp = x(2*NK*NM+1:3*NK*NM);
newlTemp = x(3*NK*NM+1:4*NK*NM);
for m = 1:NM
    cl(m,1:NK) = clTemp(((m-1)*NK+1):(m*NK));
    sl(m,1:NK) = slTemp(((m-1)*NK+1):(m*NK));
    newk(m,1:NK) = newkTemp(((m-1)*NK+1):(m*NK));
    newl(m,1:NK) = newlTemp(((m-1)*NK+1):(m*NK));
end
%% integerize the integer variables
newk = round(newk); newl = round(newl);
newkmin = (reshape(newkmin,NK,NM))';newkmax = (reshape(newkmax,NK,NM))';
newlmin = (reshape(newlmin,NK,NM))';newlmax = (reshape(newlmax,NK,NM))';
newk(newk<newkmin) = newkmin(newk<newkmin); newk(newk>newkmax) = newkmin(newk>newkmax);
newl(newl<newlmin) = newlmin(newk<newlmin); newl(newl>newlmax) = newlmin(newl>newlmax);
% BNB��ʱ��ϵͳ�����x���ɳ��ˣ����Բ�һ����������
%% the load after self-schedule
% curtailment and shift out
newLoad = load;
for m=1:NM
    newLoad(originalServiceByEnergy(m),:) = newLoad(originalServiceByEnergy(m),:) - cl(m,:) - sl(m,:); %
end
loadBeforeShiftIn = newLoad;
% shift in
shiftInLoad.fromElectricity = zeros(NL,NK);shiftInLoad.fromGas = zeros(NL,NK);shiftInLoad.fromHeat = zeros(NL,NK);
for m=1:NM
    l = originalServiceByEnergy(m);
    for k=1:NK
        
        newLoad(newl(m,k),newk(m,k)) = newLoad(newl(m,k),newk(m,k)) + sl(m,k) * eta(l,m) / eta(newl(m,k),m);
        shiftInEnergy = newl(m,k); shiftFromEnergy = originalServiceByEnergy(m); shiftInPeriod = newk(m,k);
        switch shiftFromEnergy
            case 1 
                shiftInLoad.fromElectricity(shiftInEnergy,shiftInPeriod) = sl(m,k);
            case 2
                shiftInLoad.fromGas(shiftInEnergy,shiftInPeriod) = sl(m,k);
            case 3 
                shiftInLoad.fromHeat(shiftInEnergy,shiftInPeriod) = sl(m,k);
        end
    end
end

%% cost
% --- energy purchasing cost
energyPurchasingCost = 0;
% --- customer damage cost
deltaLoadSupply = newLoad - supply;
deltaLoadSupply(find(deltaLoadSupply<0))=0;
customerDamageCost = CDF * sum(deltaLoadSupply,2);
operationalCost.LLC = zeros(1,NK);
operationalCost.LLC = CDF * deltaLoadSupply;
% --- load curtailment cost
clForEachService = sum(cl,2);
loadCurtailmentCost = CDFm * clForEachService;
operationalCost.LCC = zeros(1,NK);
operationalCost.LCC = CDFm * cl;
% --- load shifting cost
operationalCost.LSC = zeros(1,NK);
slmCost = zeros(NM,1);
for k=1:NK

        operationalCost.LSC(k) = operationalCost.LSC(k) + CDFm * sl(:,k);

end


for k=1:NK
    for m = 1:NM

        slmCost(m)= slmCost(m) + sl(m,k) * CDFm(m) /24 * abs((newk(m,k)-k));
    end
end
loadShiftingCost = sum(slmCost);

f = energyPurchasingCost + customerDamageCost + loadCurtailmentCost + loadShiftingCost;
decoupled.energyPurchasingCost = energyPurchasingCost;
decoupled.customerDamageCost = customerDamageCost;
decoupled.loadCurtailmentCost = loadCurtailmentCost;
decoupled.loadShiftingCost = loadShiftingCost;
% if isnan(f)
%     f=99999999;
% end
end

