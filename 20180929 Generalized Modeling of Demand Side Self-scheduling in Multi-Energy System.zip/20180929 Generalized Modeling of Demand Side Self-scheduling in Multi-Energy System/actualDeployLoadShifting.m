function [newActualLoad,failureFlag] = actualDeployLoadShifting(load,x,lambda)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
[NM,NL,NK,uncertaintyLevel,originalServiceByEnergy,eta,CDF,consumptionOfTotal,costOfTotal,clCoefficiency,CDFm,clPortion,slPortion,lambda] = getParameters();
%% decouple x
cl = zeros(NM,NK); sl = zeros(NM,NK); newk = zeros(NM,NK);newl = zeros(NM,NK);
clTemp = x(1:NK*NM);
slTemp = x(NK*NM+1:2*NK*NM);
newkTemp = x(2*NK*NM+1:3*NK*NM);
newlTemp = x(3*NK*NM+1:4*NK*NM);
for m = 1:NM
    cl(m,1:NK) = clTemp(((m-1)*NK+1):(m*NK));
    sl(m,1:NK) = slTemp(((m-1)*NK+1):(m*NK));
    newk(m,1:NK) = newkTemp(((m-1)*NK+1):(m*NK));
    newl(m,1:NK) = newlTemp(((m-1)*NK+1):(m*NK));   
end
  

%% the load after self-schedule
% curtailment and shift out
failureFlag = zeros(NL,NK);
newLoad = load;
for m=1:NM
    newLoad(originalServiceByEnergy(m),:) = newLoad(originalServiceByEnergy(m),:) - cl(m,:) - sl(m,:); %
end
% shift in
for m=1:NM
    l = originalServiceByEnergy(m);
    for k=1:NK
        % simulate random failure of switch in each shifting deployed process
        [DurationOfBestState,DurationOfFailureState] = MCS_switchState(lambda);
        failureFlag(originalServiceByEnergy(m),k) = 1-DurationOfBestState;
        newLoad(newl(m,k),newk(m,k)) = newLoad(newl(m,k),newk(m,k)) + sl(m,k) * eta(l,m) / eta(newl(m,k),m) * DurationOfBestState;
    end
end
newActualLoad = newLoad;
end

