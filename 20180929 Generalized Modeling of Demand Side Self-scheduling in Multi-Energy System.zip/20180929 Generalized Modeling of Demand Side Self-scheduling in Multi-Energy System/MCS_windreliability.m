function [Info_gensubsystem] = MCS_windreliability(Info_largeunit1,Info_largeunit2, mission_time)


ok = 1;
pointer1 = 1;  %% for the first unit, state pointer
pointer2 = 1;  %% for the second unit, state pointer
iter =1;

StateNumber1 = size(Info_largeunit1,1);     
StateNumber2 = size(Info_largeunit2,1); 

while ok 
    
  if iter ==1
     Info_gensubsystem(iter,1)=1;  %% State number
     Info_gensubsystem(iter,2)=0;  %% Starting time
     
  end   
    
  
  
  if Info_largeunit1(pointer1,3) <= Info_largeunit2(pointer2,3) 
     
     if pointer1 == StateNumber1  %% Point of the first unit moves to the last state 
         
          Info_gensubsystem(iter,3)=Info_largeunit1(pointer1,3);  %% This is the state end time  
          Info_gensubsystem(iter,4)=Info_largeunit1(pointer1,4) * Info_largeunit2(pointer2,4);  %% System state capacity 
          ok=0;  
        
     else 
          Info_gensubsystem(iter,3)=Info_largeunit1(pointer1,3);
          Info_gensubsystem(iter,4)=Info_largeunit1(pointer1,4) * Info_largeunit2(pointer2,4);
          pointer1 = pointer1+1;
          
          iter = iter +1;
          Info_gensubsystem(iter,1)=iter;
          Info_gensubsystem(iter,2)= Info_largeunit1(pointer1,2);
     end     
          
          
  else
     if pointer2 == StateNumber2  %% Point of the second unit moves to the last state
           
         Info_gensubsystem(iter,3)=Info_largeunit2(pointer2,3);   %% This is the state end time   
         Info_gensubsystem(iter,4)=Info_largeunit1(pointer1,4) * Info_largeunit2(pointer2,4); %% System state capacity  
         ok=0; 
      else
         Info_gensubsystem(iter,3)=Info_largeunit2(pointer2,3);
         Info_gensubsystem(iter,4)=Info_largeunit1(pointer1,4) * Info_largeunit2(pointer2,4);
         pointer2 = pointer2+1;
         
      
         iter = iter +1;
         Info_gensubsystem(iter,1)=iter;
         Info_gensubsystem(iter,2)= Info_largeunit2(pointer2,2);
     end   
  end    
    
    
end     



