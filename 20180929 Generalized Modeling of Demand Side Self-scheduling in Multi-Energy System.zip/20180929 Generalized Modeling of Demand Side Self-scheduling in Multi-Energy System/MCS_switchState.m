function [DurationOfBestState,DurationOfFailureState] = MCS_switchState(lambda)
%MCS_SWITCHSTATE Summary of this function goes here
%   Detailed explanation goes here

%% start from the best performing state
% lamda = 0.1/hour, probility of failure during switching = 0.1
switchState = 1;
if switchState == 1
    a1 = log(rand(1));
    b1 =  lambda;  %% Transition rate 
    Dur1 = - a1 /b1;%ֻ��2״̬��������
  else    
    Dur1 = 10^10;      
end    
DurationOfBestState = Dur1;
if DurationOfBestState > 1
    DurationOfBestState = 1;
    DurationOfFailureState = 0;
else    
    DurationOfFailureState = 1 - DurationOfBestState;
end

end

