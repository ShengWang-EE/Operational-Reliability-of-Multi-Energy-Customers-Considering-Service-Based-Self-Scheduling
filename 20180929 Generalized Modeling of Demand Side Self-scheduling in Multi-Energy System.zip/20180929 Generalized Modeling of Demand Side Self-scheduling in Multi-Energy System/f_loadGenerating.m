function [supply0,load0, service0,windGeneration] = f_loadGenerating()
%LOADGENERATING Summary of this function goes here
%   Detailed explanation goes here
[NM,NL,NK,uncertaintyLevel,originalServiceByEnergy,eta,CDF,consumptionOfTotal,costOfTotal,clCoefficiency,CDFm] = getParameters();
%% obtain load profile��case 1
% waterHeating: consumes electricity or gas
% ambientHeating: consumes electricity or heating
% cooking: consumes electricity or gas
% lightning: consumes electricity
% electricityOnly: 
% gasOnly
% heatingOnly
waterHeating = [0.5	0.25	0.15	0.25	0.25	1.5	3.5	4	3.75 ...	
    3.5	3	1	2	1.75	2	2.25	3	3.5	3.25	3	2.5	2	1.25	1];
ambientHeating	= [3	2.5	2.5	2.5	2.5	3	3.5	4	3.75	2.5	2	2 ...
    1.75	2	2	2	2.5	2.5	2.5	2.5	3.25	3	3	3.25];
cooking = [0.2	0.2	0	0.2	0.2	0.2	0.2	0.65	1.3	1.3	2.1	1.7	1.5	0.8	0.4	0.2	0.4	0.85	1.05	1.25	1.75	1.5	0.8	0.4];
lightning = [1	0.5	0.3	0	0	0.5	0	0	0	0	0	0	0	0	0	0	0	0.25	1	2	2.5	2.5	2.5	1.5];
electricityOnlyLoad = [1.5	0.75	0.75	0.35	0.35	1.15	1.5	2.25	3.75 ...	
    5.25	4.5	4	3.5	4.25	3.5	2.8	3.25	4	6	6.75	6	4.85	3	2.25];
sumOfLoadCurve = waterHeating + ambientHeating + cooking + lightning + electricityOnlyLoad;
electricityLoad = sumOfLoadCurve;
gasOnlyLoad = [4097.82	4098.87	4050.09	4022.87	4020.42	3983.7	3990.4 ...	
    3873.55	3816.57	3822.01	3648.24	3467.36	3876.26	3948.27	3917.98	3877.56 ...	
    3529.43	3343.65	3318.86	3274.55	3406.27	3695.28	3707.56 3940.55];
gasOnlyLoad = gasOnlyLoad / mean(gasOnlyLoad) * mean(sumOfLoadCurve) * 0.3; %normalize as 0.3
heatingOnlyLoad = [35.5	22.9	15.9	15.9	25.5	63.7	57.3	25.5	79.6	101.9	108.3 ...	
    76.4	89.2	89.2	106.4	75.2	67.1	77.4	91.4	126.3	119.2	91.2	56.1	35.1];
heatingOnlyLoad = heatingOnlyLoad / mean(heatingOnlyLoad) * mean(sumOfLoadCurve) * 0.5; %normalize as half electricity load
load0 = [electricityLoad;gasOnlyLoad;heatingOnlyLoad];% 
service0 = [waterHeating; ambientHeating; cooking; lightning; electricityOnlyLoad; gasOnlyLoad; heatingOnlyLoad;];
% energy supply
electricitySupply = mean(sumOfLoadCurve) * ones(1,24);
gasSupply = mean(gasOnlyLoad) * ones(1,24);
heatSupply = mean(heatingOnlyLoad) * ones(1,24);
supply0 = [electricitySupply;gasSupply;heatSupply];
%% obtain the load profile: case 2
TCLproportion = [190 180 160 145 130 110 90 100 120 130 150 180 205 205 180 180 160 155 160 215 240 255 245 210]...
    ./ [230 205 190 180 165 170 165 165 190 210 235 245 265 270 240 245 235 245 260 320 350 360 310 260];
electricityLoad01 = [2.802656916	2.575823419	2.39647028	2.291468401	2.1939011	2.332979227	2.488730163	3.13709239	3.393232526	3.480451985	4.087105023	4.190399869	4.248256418	3.741306443	3.450126625	3.573395423	3.934869078	4.715334181	5.08458215	4.739740701	4.693497081	4.306320679	3.210392136	2.874414218];
heatLoad01 = [0.176152021	0.042090177	0.088237991	0.106200851	0.193693753	0.215287016	0.291038	0.442340426	1.206382979	1.34712766	1.447659574	1.608510638	1.568297872	1.548191489	1.729148936	1.709042553	1.749255319	1.89	1.809574468	1.89	1.769361702	1.125957447	0.489087839	0.300308793];
gasLoad01 = zeros(1,24);
waterHeating01 = waterHeating./(waterHeating + ambientHeating) .* electricityLoad01 .* TCLproportion;
ambientHeating01 = ambientHeating./(waterHeating + ambientHeating) .* electricityLoad01 .* TCLproportion;
cooking01 = zeros(1,24);
lighting01 = lightning./(lightning+cooking+electricityOnlyLoad) .* electricityLoad01 .* (1-TCLproportion);
electricityOnlyLoad01 = electricityOnlyLoad./(lightning+cooking+electricityOnlyLoad) .* electricityLoad01 .* (1-TCLproportion);
load0 = [electricityLoad01;gasLoad01;heatLoad01];
service0 = [waterHeating01; ambientHeating01; cooking01; lighting01; electricityOnlyLoad01; gasLoad01; heatLoad01;];
% energy supply
electricitySupply = mean(electricityLoad01) * ones(1,24);
gasSupply = mean(gasLoad01) * ones(1,24);
heatSupply = mean(heatLoad01) * ones(1,24);
supply0 = [electricitySupply;gasSupply;heatSupply];
%% integrate load uncertaintis
% MCS

service1 = service0 * (1-uncertaintyLevel); load1 = load0 * (1-uncertaintyLevel);
loadState = [1,2,3,4]; % state = [valley flat1 peak flat2]
[InfoLoadLevel] = MCS_loadLevel(NK);
InfoLoadLevel(end,3) = NK;
% determine the service after considering uncertainty

for m = 1:NM
    for k = 1:NK
        % ѡ��k��������ʱ��֮��
        [beginTime, beginTimeIndex] = max(InfoLoadLevel(find(InfoLoadLevel(:,2)<=(k-1)),2));
        [endTime, endTimeIndex] = max(InfoLoadLevel(find(InfoLoadLevel(:,2)<(k)),2));
        loadIncrease = 0;localBeginTime = beginTime;
        for i=beginTimeIndex:endTimeIndex
            loadIncreaseCaseIdentifier = 10 * (i == beginTimeIndex) + (i == endTimeIndex);
            switch loadIncreaseCaseIdentifier
                case 11
                    loadIncrease = loadIncrease + 1 * InfoLoadLevel(i,4);
                case 10
                    loadIncrease = loadIncrease + (InfoLoadLevel(i,3) - (k-1)) * InfoLoadLevel(i,4);
                case 1
                    loadIncrease = loadIncrease + (k - InfoLoadLevel(i,2)) * InfoLoadLevel(i,4);
                case 0
                    loadIncrease = loadIncrease + (InfoLoadLevel(i,3) - InfoLoadLevel(i,2)) * InfoLoadLevel(i,4);
            end           
        end
        service1(m,k) = service1(m,k) + 2 * uncertaintyLevel * service0(m,k) * loadIncrease;%
    end
end
load1 = [sum(service1(1:5,:)); service1(6,:); service1(7,:)];

%% integrate wind uncertainties
windGeneration = MCS_windfarm(24);
windGeneration(:,4) = windGeneration(:,4) / 200; %2.5MW winf turbine
load2 = load0;
windGeneration(:,4) = -windGeneration(:,4);
windGeneration(end,3) = 24;
load2(1,:) = loadMerging(load0(1,:),windGeneration);
load2(find(load2<0)==0);
end

